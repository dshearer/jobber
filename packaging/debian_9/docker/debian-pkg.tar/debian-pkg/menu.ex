?package(jobber):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="jobber" command="/usr/bin/jobber"
