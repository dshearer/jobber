// Package unused does something
package unused

func Yo() {
}
