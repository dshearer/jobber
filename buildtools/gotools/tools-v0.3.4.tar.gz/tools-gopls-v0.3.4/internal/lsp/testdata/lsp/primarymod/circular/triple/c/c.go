package c

import (
	_ "golang.org/x/tools/internal/lsp/circular/triple/a"
)
