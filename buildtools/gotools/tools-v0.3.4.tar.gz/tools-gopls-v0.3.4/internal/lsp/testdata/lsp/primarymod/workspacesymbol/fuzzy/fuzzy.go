package fuzzy

/*@
workspacesymbolfuzzy("wsym",
	WorkspaceSymbolVariableA,
	WorkspaceSymbolConstantA,
	workspacesymbolinvariable,
	WorkspaceSymbolVariableB,
	WorkspaceSymbolStructB,
)
workspacesymbolfuzzy("symbola",
	WorkspaceSymbolVariableA,
	WorkspaceSymbolConstantA,
	workspacesymbolinvariable,
	WorkspaceSymbolVariableB,
)
workspacesymbolfuzzy("symbolb",
	WorkspaceSymbolVariableA,
	workspacesymbolinvariable,
	WorkspaceSymbolVariableB,
	WorkspaceSymbolStructB,
)
*/
