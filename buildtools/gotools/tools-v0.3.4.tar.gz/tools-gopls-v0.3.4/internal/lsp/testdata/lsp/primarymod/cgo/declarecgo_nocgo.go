//+build !cgo

package cgo

// Set a dummy marker to keep the test framework happy. The tests should be skipped.
var _ = "Example" //@mark(funccgoexample, "Example")
