package references

import (
	"testing"
)

// This test exists to bring the test package into existence.

func TestReferences(t *testing.T) {
}
