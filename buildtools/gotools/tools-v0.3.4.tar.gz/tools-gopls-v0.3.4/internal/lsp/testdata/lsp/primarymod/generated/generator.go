package generated

func _() {
	var x int //@diag("x", "compiler", "x declared but not used", "error")
}
