package casesensitive

/*@
workspacesymbolcasesensitive("baz", baz)
workspacesymbolcasesensitive("Baz", Baz)
*/
