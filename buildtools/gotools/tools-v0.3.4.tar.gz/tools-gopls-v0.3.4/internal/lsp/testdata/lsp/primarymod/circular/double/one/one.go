package one

import (
	_ "golang.org/x/tools/internal/lsp/circular/double/b"
)