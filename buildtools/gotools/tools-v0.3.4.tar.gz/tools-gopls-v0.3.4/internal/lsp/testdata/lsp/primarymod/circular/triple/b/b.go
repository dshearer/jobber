package b

import (
	_ "golang.org/x/tools/internal/lsp/circular/triple/c"
)
