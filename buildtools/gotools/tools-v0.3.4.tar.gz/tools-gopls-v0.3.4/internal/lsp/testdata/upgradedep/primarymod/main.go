// Package upgradedep does something
package upgradedep

import (
	"example.com/extramodule/pkg"
)

func Yo() {
	_ = pkg.Test
}
