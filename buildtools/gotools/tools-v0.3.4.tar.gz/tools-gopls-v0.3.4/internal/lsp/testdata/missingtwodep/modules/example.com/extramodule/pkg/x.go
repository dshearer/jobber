package pkg

const Test = 1