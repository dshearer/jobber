// Package unchanged does something
package unchanged

func Yo() {
	println("yo")
}
