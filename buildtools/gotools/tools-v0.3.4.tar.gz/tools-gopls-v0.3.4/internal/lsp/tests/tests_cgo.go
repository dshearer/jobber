// +build cgo

package tests

func init() {
	haveCgo = true
}
